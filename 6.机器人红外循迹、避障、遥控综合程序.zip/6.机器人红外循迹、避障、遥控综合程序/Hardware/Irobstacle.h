#ifndef __IROBSTACLE_H
#define __IROBSTACLE_H

void Irobstacle_Init(void);
uint8_t Left_Irobstacle_Get(void);
uint8_t Right_Irobstacle_Get(void);

#endif
