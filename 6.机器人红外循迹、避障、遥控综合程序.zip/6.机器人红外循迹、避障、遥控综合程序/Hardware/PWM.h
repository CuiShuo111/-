#ifndef __PWM_H
#define __PWM_H

void PWM_Init(void);//uint16_t arr,uint16_t psc);

#endif
