#ifndef __IRTRACKING_H
#define __IRTRACKING_H

void Irtracking_Init(void);
uint8_t Left_Irtracking_Get(void);
uint8_t Right_Irtracking_Get(void);

#endif
