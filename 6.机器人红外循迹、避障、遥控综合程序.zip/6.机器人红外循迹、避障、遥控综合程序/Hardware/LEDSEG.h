#ifndef __LEDSEG_H
#define __LEDSEG_H

void LEDSEG_Init(void);
void Digital_Display(uint8_t val);

#endif
